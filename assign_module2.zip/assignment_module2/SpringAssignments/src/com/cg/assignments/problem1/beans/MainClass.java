package com.cg.assignments.problem1.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class MainClass {
	public static void main(String[] args) {
		System.out.println("-------Employee info------");
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		Employee employee=(Employee)applicationContext.getBean("employeeDetails");
		System.out.println("ID :"+employee.getEmployeeId()+" "+"name :"+employee.getEmployeeName()+" "+"salary :"
				+employee.getSalary()+" "+"business unit:"+employee.getBusinessUnit().getSbuId()+" "+employee.getBusinessUnit().getSbuName()
				+" "+employee.getBusinessUnit().getSbuHead());
	} 

}
