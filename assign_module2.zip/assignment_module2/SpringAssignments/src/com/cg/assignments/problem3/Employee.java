package com.cg.assignments.problem3;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("aanchalEmp")
public class Employee {
	
	@Value("100")
	private int employeeId;
	@Value("22")
	private int age;
	@Value("aanchal")
	private String employeeName;
	@Value("PES-BU")
	private String buName;
	@Value("30000.0")
	private double salary;
	
	
	
	public Employee() {}
	public Employee(int employeeId, int age, String employeeName, String buName, double salary) {
		super();
		this.employeeId = employeeId;
		this.age = age;
		this.employeeName = employeeName;
		this.buName = buName;
		this.salary = salary;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getBuName() {
		return buName;
	}
	public void setBuName(String buName) {
		this.buName = buName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "employeeId=" + employeeId + ", age=" + age + ", employeeName=" + employeeName + ", buName="
				+ buName + ", salary=" + salary;
	}
	
	

}
