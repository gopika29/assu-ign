package com.cg.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Bill;
import com.cg.beans.Consumer;
import com.cg.dao.ElectricityDao;

@Service
public class ElectricityServicesImpl implements ElectricityServices{
	@Autowired
	ElectricityDao electricityDao;

	public ElectricityDao getElectricityDao() {
		return electricityDao;
	}
	public void setElectricityDao(ElectricityDao electricityDao) {
		this.electricityDao = electricityDao;
	}

	@Override
	public Consumer addConsumer(Consumer consumer) {

		return electricityDao.addConsumer(consumer);
	}
	@Override
	public ArrayList<Consumer> retrieveAllConsumers() {
		
		return electricityDao.retrieveAllConsumers();
	}
	@Override
	public Consumer retrieveConsumer(int consumerNo) {
		
		return electricityDao.retrieveConsumer(consumerNo);
	}
	@Override
	public Bill addBill(Bill bill) {
		
		return electricityDao.addBill(bill);
	}
	@Override
	public ArrayList<Bill> retrieveAllBills() {
		
		return electricityDao.retrieveAllBills();
	}

}
