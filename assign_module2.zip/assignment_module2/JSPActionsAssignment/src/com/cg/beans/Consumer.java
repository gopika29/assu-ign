package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cg_consumer")
public class Consumer {
	@Id
	@Column
	private int consumerNo;
	@Column
	private String consumerName;
	@Column
	private String address;

	public Consumer() {}

	public int getConsumerNo() {
		return consumerNo;
	}

	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Consumer(int consumerNo, String consumerName, String address) {
		super();
		this.consumerNo = consumerNo;
		this.consumerName = consumerName;
		this.address = address;
	}

	@Override
	public String toString() {
		return "consumerNo=" + consumerNo + ", consumerName=" + consumerName + ", address=" + address;
	}


}
