package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cg_bill")
public class Bill {
	@Id
	@Column
	private int billNumber;
	@Column
	private String billMonth;
	@Column
	private double meterReading;
	@Column
	private double billAmount;
	@Column
	private double unitComsumed;

	public Bill() {	}

	
	public int getBillNumber() {
		return billNumber;
	}
public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}
public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public double getMeterReading() {
		return meterReading;
	}
	public void setMeterReading(double meterReading) {
		this.meterReading = meterReading;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public double getUnitComsumed() {
		return unitComsumed;
	}
	public void setUnitComsumed(double unitComsumed) {
		this.unitComsumed = unitComsumed;
	}

	public Bill(int billNumber, String billMonth, double meterReading, double billAmount, double unitComsumed) {
		super();
		this.billNumber = billNumber;
		this.billMonth = billMonth;
		this.meterReading = meterReading;
		this.billAmount = billAmount;
		this.unitComsumed = unitComsumed;
	}

	@Override
	public String toString() {
		return "billNumber=" + billNumber+ ", billMonth=" + billMonth + ", meterReading=" + meterReading
				+ ", billAmount=" + billAmount + ", unitComsumed=" + unitComsumed;
	}
}






