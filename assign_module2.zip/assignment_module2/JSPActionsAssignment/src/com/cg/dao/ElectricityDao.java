package com.cg.dao;

import java.util.ArrayList;

import com.cg.beans.Bill;
import com.cg.beans.Consumer;

public interface ElectricityDao {
	
	public Consumer addConsumer(Consumer consumer);
	public Bill addBill(Bill bill);
	public ArrayList<Consumer> retrieveAllConsumers();
	public ArrayList<Bill> retrieveAllBills();
	public Consumer retrieveConsumer(int consumerNo);

}
