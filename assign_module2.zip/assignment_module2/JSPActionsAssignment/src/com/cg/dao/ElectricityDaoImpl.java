package com.cg.dao;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.beans.Bill;
import com.cg.beans.Consumer;


@Repository															
@Transactional		
public class ElectricityDaoImpl implements ElectricityDao {

	@PersistenceContext																	
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public Consumer addConsumer(Consumer consumer) {
	
		entityManager.persist(consumer);
		return consumer;
	}
	@Override
	public ArrayList<Consumer> retrieveAllConsumers() {
	
		return (ArrayList<Consumer>) entityManager.createQuery("from Consumer c").getResultList();
	}
	@Override
	public Consumer retrieveConsumer(int consumerNo) {
		
		Consumer consumer=entityManager.find(Consumer.class, consumerNo);
		return consumer;
		
	}
	@Override
	public Bill addBill(Bill bill) {
		
		entityManager.persist(bill);
		return bill;

		

	}
	@Override
	public ArrayList<Bill> retrieveAllBills() {
		
		return (ArrayList<Bill>) entityManager.createQuery("from Bill b").getResultList();
	}

}
