package com.cg.controllers;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.beans.Bill;
import com.cg.beans.Consumer;
import com.cg.services.ElectricityServices;



@Controller
public class ElectricityController {

	@Autowired
	ElectricityServices electricityServices;

	public ElectricityServices getElectricityServices() {
		return electricityServices;
	}
	public void setElectricityServices(ElectricityServices electricityServices) {
		this.electricityServices = electricityServices;
	}

	@RequestMapping(value="/addConsumer",method=RequestMethod.GET)
	public String displayConsumerPage(Model model) {
		model.addAttribute("add", new Consumer());
	
		return "AddConsumer";
	}
	@RequestMapping(value="/Insert", method=RequestMethod.POST)
	public String addConsumerDetails(@ModelAttribute(value="add") @Valid Consumer consumer,BindingResult result,Model model) {
		
		
			electricityServices.addConsumer(consumer);
			model.addAttribute("msg","data is successfully added");
			return "AddConsumer";
		}
	@RequestMapping(value="/addBill",method=RequestMethod.GET)
	public String displayBillPage(Model model) {
		model.addAttribute("Add", new Bill());
	
		return "AddBill";
	}
	@RequestMapping(value="/InsertBill", method=RequestMethod.POST)
	public String addBillDetails(@ModelAttribute(value="Add") @Valid Bill bill,BindingResult result,Model model) {
		
		electricityServices.addBill(bill);
			model.addAttribute("msg","data is successfully added");
			return "AddBill";
		}
	@RequestMapping(value="/retrieveAllConsumer",method=RequestMethod.GET ) 
	public String showAllRetrieveMessge( Model model) {

		model.addAttribute("msgList",electricityServices.retrieveAllConsumers());
		return "RetrieveAll";
	}
	
	@RequestMapping(value="/retrieveAllBill",method=RequestMethod.GET ) 
	public String showAllBillRetrieveMessge( Model model) {

		model.addAttribute("msgList",electricityServices.retrieveAllBills());
		return "RetrieveAllBill";
	}
	
	@RequestMapping(value="/retrieveConsumer",method=RequestMethod.GET ) 
	public String showRetrieveMessage( Model model) {
		Consumer consumer=new Consumer();
		model.addAttribute("retrieve",consumer);


		return "SearchConsumer";

	}
	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public String retrieveTrainee(@ModelAttribute(value="retrieve") @Valid Consumer consumer,BindingResult result,Model model) {


		model.addAttribute("msg","data is successfully retrieved");
		model.addAttribute("details",electricityServices.retrieveConsumer(consumer.getConsumerNo()));

		return "SearchConsumer";

	}
	}



