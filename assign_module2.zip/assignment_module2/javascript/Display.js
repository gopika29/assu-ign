<!DOCTYPE html>
<html>
<body>

<h2>hello world display</h2>

<p>This is js file to print hello world:</p>

<p id="demo"></p>
<script>
function display() {
  return "hello";
}
document.getElementById("demo").innerHTML = display();
</script>

</body>
</html>
