package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Login;
@WebServlet("/logIn")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String userName=request.getParameter("userName");
String password=request.getParameter("password");
	Login bean=new Login(userName,password);
	RequestDispatcher dispatcher=null;
if(bean.getUserName().equals("aanchal") && bean.getPassword().equals("aanchal"))
{
	dispatcher=request.getRequestDispatcher("Success.jsp");
request.setAttribute("bean", bean);
dispatcher.forward(request, response);
 }
 else {
	 dispatcher=request.getRequestDispatcher("LoginPage.jsp");
	 request.setAttribute("error", "user id or password is wrong");
	 dispatcher.forward(request, response);
 }
	 
 }
}
