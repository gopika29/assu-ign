package com.cg.banking.beans;



import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="Customer_Spring")
public class Customer {
	@Id
	private int customerId;
	private String firstName,lastName,emailId,pancard;
	private Date dateOfBirth;
	private long mobileNo,adharNo;
	@Embedded
	private Address  address;
	@OneToOne(mappedBy="customer")
	private Account account;
	
	public Customer() {
	}

	



	public Customer(String firstName, String lastName, String emailId, String pancard, Date dateOfBirth, long mobileNo,
			long adharNo, Address address, Account account) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancard = pancard;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.address = address;
		this.account = account;
	}





	public Customer(String firstName, String lastName, String emailId, String pancard, Date dateOfBirth, long mobileNo,
			long adharNo, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancard = pancard;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.address = address;
	}





	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public long getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}


	public long getAdharNo() {
		return adharNo;
	}


	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPancard() {
		return pancard;
	}


	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}

	public Account getAccount() {
		return account;
	}


	public void setAccount(Account account) {
		this.account = account;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", pancard=" + pancard + ", dateOfBirth=" + dateOfBirth + ", mobileNo="
				+ mobileNo + ", adharNo=" + adharNo + ", address=" + address + ", account=" + account + "]";
	}


	


	
	
	
	
}
