package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Account;
@Repository("accountDAO")
@Transactional
public class AccountDAOImpl implements AccountDAO{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Account save(Account account) {
		entityManager.persist(account);
		entityManager.flush();
		return account;
	}

	@Override
	public boolean update(Account account) {
		
		entityManager.merge(account);
		entityManager.flush();
		return true;
	}

	@Override
	public Account findOne(long accountNo) {
		return entityManager.find(Account.class, accountNo);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> findAll() {
		return entityManager.createQuery("from Account a").getResultList();
	}

}
