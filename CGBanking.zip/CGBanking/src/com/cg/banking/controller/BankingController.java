package com.cg.banking.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingController {
	@Autowired
	BankingServices bankingServices;
	public BankingServices getBankingServices() {
		return bankingServices;
	}
	public void setBankingServices(BankingServices bankingServices) {
		this.bankingServices = bankingServices;
	}
	@RequestMapping(value="/openAccountPage",method=RequestMethod.GET)
	public String displayOpenAccount(Model model) {
		model.addAttribute("openAccount", new Account());
		return "openAccountPage";
	}
	@RequestMapping(value="/openAccount",method=RequestMethod.POST)
	public String openAccount(@ModelAttribute(value="openAccount")Account account,Model model) {
		try {
			model.addAttribute("account",bankingServices.openAccount(account.getAccountType(), account.getAccountBalance()));
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			e.printStackTrace();
		}
		model.addAttribute("message", "account Opened");
		return "openAccountPage";
	}
	//--------------open Account2---------------------------------------
	@RequestMapping(value="/openAccountPage2",method=RequestMethod.GET)
	public ModelAndView displayOpenAccount2() {
		/*	//model.addAttribute("Account", new Account());
		model.addAttribute("Customer",new Customer());
		//model.addAttribute("Address",new Address());
		 */		HashMap<String, Object> model=new HashMap<>();
		 model.put("Account", new Account());
		 model.put("Customer", new Customer());
		 model.put("Address",new Address());
		 return new ModelAndView("OpenAccount","beans", model);
	}
	/*//----------------------------openAccount2----------------------------------------------
	@RequestMapping(value="/openAccount2",method=RequestMethod.POST)
	public String openAccount2(@ModelAttribute(value="Account")Account account,
			@ModelAttribute(value="Customer")Customer customer,@ModelAttribute(value="Address")
	Address address,Model model) {
		try {
			model.addAttribute("account",bankingServices.openAccount2(customer, account));
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {
			e.printStackTrace();
		}
		model.addAttribute("message", "account Opened");
		return "OpenAccount";
	}*/
	@RequestMapping(value="/showLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		model.addAttribute("login", new Account());
		return "LoginPage";
	}

	@RequestMapping(value="/validateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="login") @Valid Account account,BindingResult result,
			Model model) {
		if(result.hasErrors())
			return "LoginPage";
		else {
			try {
				if(bankingServices.loginValidation(account.getAccountNo(), account.getPinNumber())) {
					return "TransactionPage";
				}
				else
					model.addAttribute("failure", "your username or password are wrong");
			} catch (AccountNotFoundException | BankingServicesDownException e) {
				e.printStackTrace();
			}
			return "LoginPage";
		}
	}
	@RequestMapping(value="/displayDeposit",method=RequestMethod.POST)
	public String displayDepositAmountPage(Model model,@ModelAttribute(value="login")Account account) {
		return "DepositPage";
	}
	@RequestMapping(value="/DepositAmount",method=RequestMethod.POST)
	public String DepositAmount(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="depositAmount")float amount) {
		try {
			bankingServices.depositAmount(account.getAccountNo(), amount);
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("deposited", "amount deposited successfully");
		return "DepositPage";
	}
	@RequestMapping(value="/displayWithdraw",method=RequestMethod.POST)
	public String displayWithdrawAmountPage(Model model,@ModelAttribute(value="login")Account account) {
		return "WithdrawPage";
	}
	@RequestMapping(value="/WithdrawAmount",method=RequestMethod.POST)
	public String WithdrawAmount(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="withdrawAmount")float amount) {
		try {
			bankingServices.withdrawAmount(account.getAccountNo(), amount, account.getPinNumber());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("withdraw", "amount withdrawl successfully");
		return "WithdrawPage";
	}
	@RequestMapping(value="/displayFundTransfer",method=RequestMethod.POST)
	public String displayFundTransferPage(Model model,@ModelAttribute(value="login")Account account) {
		return "FundTransferPage";
	}
	@RequestMapping(value="/FundTransfer",method=RequestMethod.POST)
	public String FundTransfer(Model model,@ModelAttribute(value="login")Account account,
			@RequestParam(value="TransferAmount")float amount,@RequestParam(value="accountNoTo")long accountNoTo) {
		try {
			bankingServices.fundTransfer(accountNoTo,account.getAccountNo(),amount, account.getPinNumber());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("success", "amount Transfered successfully");
		return "FundTransferPage";
	}
}
