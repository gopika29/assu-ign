package com.cg.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.beans.Product;
import com.cg.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@Override
	public List<Product> getAllProducts() {

		return productDao.getAllProducts();
	}

	@Override
	public void addProduct(Product country) {
		productDao.addProduct(country);
	}

	@Override
	public Product deleteProduct(int productId) {

		return productDao.deleteProduct(productId);
	}

	@Override
	public Product searchProduct(int productId) {

		return productDao.searchProduct(productId);
	}

}
