package com.cg.staticdb;

import java.util.ArrayList;
import com.cg.beans.Product;

public class ProductDB {

	private static ArrayList<Product> productList=new ArrayList<Product>();

	public static ArrayList<Product> getProductList() {
		return productList;
	}
	public static void setProductList(ArrayList<Product> productList) {
		ProductDB.productList = productList;
	}
	static {
		productList.add(new Product(911,"Microphone",15353.0));
		productList.add(new Product(912,"IPod",45353.0));
		productList.add(new Product(913,"IPhone",67377.0));
		
	}
}
