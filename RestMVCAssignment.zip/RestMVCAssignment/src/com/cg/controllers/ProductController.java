package com.cg.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Product;
import com.cg.services.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService service;

	public ProductService getService() {
		return service;
	}

	public void setService(ProductService service) {
		this.service = service;
	}

	@RequestMapping(value="/products/search/{id}",method=RequestMethod.GET,headers="Accept=application/json")
	public  Product getProduct(@PathVariable int id) {
		return service.searchProduct(id);
	}
	
	@RequestMapping(value="/products",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Product> getAllProducts(Model model) {
		return service.getAllProducts();
	}
	

	@RequestMapping(value = "/products/create/{id}/{name}/{price}",produces = "application/json",
			 method = RequestMethod.POST)  //headers="Accept=application/json",
	public List<Product> createProduct(@PathVariable int id,@PathVariable String name,@PathVariable double price,ModelAndView model) {
		Product product=new Product();
		product.setProductId(id);
		product.setProductName(name);
		product.setProductPrice(price);
		service.addProduct(product);
		//model.setViewName("show.jsp");
		return service.getAllProducts();
	}
	
	@RequestMapping(value="/products/delete/{id}",method=RequestMethod.DELETE,headers="Accept=application/json")
	public List<Product> deleteProduct(@PathVariable int id){
	 service.deleteProduct(id);
		return service.getAllProducts();
		
	}

}
