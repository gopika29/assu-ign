package com.cg.dao;

import java.util.List;
import com.cg.beans.Product;
import com.cg.staticdb.ProductDB;


public class ProductDaoImpl implements ProductDao{

	@Override
	public List<Product> getAllProducts() {
		
		return ProductDB.getProductList();
	}

	@Override
	public void addProduct(Product product) {
		
		ProductDB.getProductList().add(product);
	}

	@Override
	public Product deleteProduct(int productId) {
		
		return ProductDB.getProductList().remove(productId);
	}

	@Override
	public Product searchProduct(int productId) {
	
		return 	ProductDB.getProductList().stream().filter(c->(c.getProductId())==productId).findFirst().get();
	}

}
