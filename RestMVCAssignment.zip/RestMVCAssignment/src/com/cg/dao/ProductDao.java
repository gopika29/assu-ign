package com.cg.dao;

import java.util.List;

import com.cg.beans.Product;



public interface ProductDao {
	public List<Product> getAllProducts();
	public void addProduct(Product product);
	public Product deleteProduct(int productId);
	public Product searchProduct(int productId);

}
