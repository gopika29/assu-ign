package com.cg.hotelbooking.stepdefinition;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.cg.hotelbooking.SeleniumHotelBookingMaintainable;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {
	static WebDriver driver=null;
	String title,currentUrl,message;
	@Before
	public void openWebDriver() {
		driver=new FirefoxDriver();
	}
	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
	   driver.get("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/hotelbooking.html");
	   title=driver.getTitle();
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	   assertEquals("Hotel Booking",title);
	}
	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		currentUrl=SeleniumHotelBookingMaintainable.driverTesting();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		assertEquals(currentUrl,"file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/success.html");
	}
	@When("^user leaves firstName as blank and clicks the button$")
	public void user_leaves_firstName_as_blank_and_clicks_the_button() throws Throwable {
	  // message=SeleniumHotelBookingMaintainable.checkFirstName();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
	    //assertEquals(message, "Please fill the First Name");
	}
	@After
	public void closeWebDriver() {
		driver.close();
	}
}
